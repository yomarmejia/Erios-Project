#!/bin/bash

#############################################################
#                       FfmpegVA.sh                         #
#############################################################

find / -name userIC.txt > .dir-ffmpeg.txt
sed -i "s|/userIC.txt||g" .dir-ffmpeg.txt
dirffmpeg="$(cat .dir-ffmpeg.txt)" > /dev/null 2>&1


userIC="$(cat $dirffmpeg/userIC.txt)" > /dev/null 2>&1
passIC="$(cat $dirffmpeg/passIC.txt)" > /dev/null 2>&1
resIC="$(cat $dirffmpeg/resIC.txt)" > /dev/null 2>&1
$Web="$(cat $dirffmpeg/Web.txt)" > /dev/null 2>&1
sed -i "s|http://||g" $dirffmpeg/Web.txt > /dev/null 2>&1

ffmpeg -f v4l2 -video_size 640x480 -framerate 30 -i /dev/video0 -f alsa -i default -f webm -cluster_size_limit 2M -cluster_time_limit 5100 -content_type video/webm -c:a libvorbis -b:a 96K -c:v libvpx -b:v 1.5M -crf 30 -g 150 -deadline good -threads 4 icecast://$userIC:$passIC@$Web:8000/$resIC
