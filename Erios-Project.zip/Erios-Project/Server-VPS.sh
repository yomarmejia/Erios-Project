#!/bin/bash

########################################################
#          Creación de las variables basicas           #
########################################################

path=`pwd`
arch=`uname -m`
config=$path/config/config.path

# Colores
cian='\e[0;36m'
verde='\e[0;32m'
rojo='\e[1;31m'
amarillo='\e[1;33m'
azul='\e[0;34m'
morado='\e[1;35m'

#######################################################
#                Comprobación de root                 #
#######################################################

if [ $(id -u) != "0" ]; then
echo -e $rojo[x] Es esencial ser $azul [root] $rojo para ejecutar este setup [x]
echo " "
sleep 2s
exit 0
fi

########################################################
#              Aviso de SSH con ejecución              #
########################################################

echo -e $verde "ATENCION!"
sleep 2s
echo -e $verde "Si estas ejecutando este script remotamente con el programa SSH"
sleep 2s
echo -e $verde "Asegurate de que sea con la variable de ejecución"
sleep 2s
echo " "
echo -e $verde "El comando para Linux es el siguiente: $azul ssh -X usuario@servidor"
sleep 2s
echo -e $verde "Y para Windows solo hay que activar el X11 en el programa usado"
read -n1 -r -p "Presiona [ Enter ] cuando quieras continuar" key
clear

########################################################
#            Comprobaciones de sources.list            #
########################################################

file="/etc/apt/sources.list.alarma"
if [ -f $file ]; then
echo -e $verde "Se esta reparando tu lista de repositorios porque se ha detectado que se ha interrumpido una instalación o una actualización"
sleep 3s
rm -f /etc/apt/sources.list
mv /etc/apt/sources.list.alarma /etc/apt/sources.list
echo "Se ha recuperado la lista de repositorios original"
echo "Empezando la instalación de lios paquetes"
echo " "
echo "Limpieza de la cache de los anteriores repositorios y acutualizando la lista"
apt clean && apt update -y > /dev/null 2>&1
sleep 2s 
else 
echo -e $verde "Todo en orden"
fi
clear

########################################################
#                       Banner                         #
########################################################

resize -s 21 70 > /dev/null 2>&1

echo -e $cian "╔═══════════════════════════════════════════════════════════════════╗"
echo -e "║                                                                   ║"
echo -e "║                         Erios Project                             ║"
echo -e "║ $rojo         0                                           0           $cian ║"
echo -e "║ $rojo        0       0                             0       0          $cian ║"
echo -e "║ $rojo       0       0     0       00000       0     0       0         $cian ║"
echo -e "║ $rojo      0       0     0      00     00      0     0       0        $cian ║"
echo -e "║ $rojo      0      0     0      0         0      0     0      0        $cian ║"
echo -e "║ $rojo      0      0     0      0    0    0      0     0      0        $cian ║"
echo -e "║ $rojo      0      0     0      0         0      0     0      0        $cian ║"
echo -e "║ $rojo      0       0     0      00     00      0     0       0        $cian ║"
echo -e "║ $rojo       0       0     0       00000       0     0       0         $cian ║"
echo -e "║ $rojo        0       0                             0       0          $cian ║"
echo -e "║ $rojo         0                                           0           $cian ║"
echo "║                                                                   ║"
echo "║                              Creado por:                          ║"
echo "║                                                                   ║"
echo "║                        Yomar Stalin Mejia Capa                    ║"
echo "║                         David Naranjo Risueño                     ║"
echo "╚═══════════════════════════════════════════════════════════════════╝"
sleep 5s
clear

########################################################
#              Comprobación de internet                #
########################################################

echo -e $verde "Comprobando la conexión a internet"
sleep 3s
ping -c 1 google.com > /dev/null 2>&1
if [ "$?" != "0" ]; then
echo -e $rojo "No tienes conexión a internet. Para ejecutar este script es necesaria."
read -n1 -r -p "Se parara la ejecuión. Presiona [ Enter ] para salir" key
exit 0
else
echo -e $verde "Todo correcto!"
sleep 1s
fi
clear


########################################################
#                       Xterm                          #
########################################################

which xterm > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul Xterm $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " --- $azul Xterm $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando XTerm Δ "
apt install xterm -y > /dev/null 2>&1
echo -e $verde "     ✔ Instalado!"
echo " "
find /home -name .Xauthority > dir-xterm.txt
dirxterm="$(cat dir-xterm.txt)" > /dev/null 2>&1
cp $dirxterm ~/ > /dev/null 2>&1
sleep 2s
fi

########################################################
#                      IceCast 2                       #
########################################################

which icecast2 > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul IceCast2 $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " ---$azul IceCast2 $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando IceCast2 Δ "
xterm -T "Δ Instalando IceCast2 Δ" -geometry 100x30 -e "sudo DEBIAN_FRONTEND=noninteractive apt install icecast2 -y"
echo -e $verde "     ✔ Instalado!"
echo " "
sleep 3s
fi
clear

########################################################
#                      Apache2                         #
########################################################

which apache2 > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul Apache2 $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " ---$azul Apache2 $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando Apache2 Δ "
xterm -T "Δ Instalando Apache2 Δ" -geometry 100x30 -e "sudo DEBIAN_FRONTEND=noninteractive apt install apache2 -y"
echo -e $verde "     ✔ Instalado!"
echo " "
sleep 3s
fi
clear

#################################################################
#                   Creación Carpeta Scripts                    #
#################################################################

# Creación del directorio donde se alojará todos los scripts del sistema de videovigilancia.

find /home -name Erios-Project-DDNS.sh > directory.txt
sed -i "s|Erios-Project-VPS.sh| |g" directory.txt
directory="$(cat directory.txt)" > /dev/null 2>&1
cp -r $directory ~/ > /dev/null 2>&1
mkdir ~/.Scripts-Erios > /dev/null 2>&1
sleep 5s
clear

########################################################
#              Configuración de IceCast2               #
########################################################

icecast_file=/etc/icecast2/icecast.xml

# Creación de usuario y contraseña para la página web
echo -e -n $verde "Introduce el usuario de acceso a Icecast: "
read icecast_user
echo $icecast_user > ~/.Scripts-Erios/userIC.txt
echo " "
echo -e -n $verde "Introduce la contraseña de acceso a Icecast: "
read -s icecast_pass
echo icecast_pass > ~/.Scripts-Erios/passIC.txt
echo " "
echo -e -n $verde "Instroduce el nombre del recurso para la imagen con la extension .ogg (Por ejemplo: video.ogg): "
read resource
echo $resource > ~/.Scripts-Erios/resIC.txt
echo " "
echo -e -n $verde "Cual es el máximo de usuarios que van a acceder a la vez? [1 a 9]: "
read listeners
echo " "
echo -e -n $verde "Introduce la dirección Web o DNS del Servidor VPS: "
read Web
echo $Web > ~/.Scripts-Erios/Web.txt
echo " "

# Modificiación del archivo /etc/icecast2/icecast.xml
rm -rf /etc/icecast2/icecast.xml
mv ~/Erios-Project/icecast.xml /etc/icecast2/
sleep 1s
sed -i "s|<source-password>hackme</source-password>|<source-password>$icecast_pass</source-password>|g" $icecast_file > /dev/null 2>&1
sed -i "s|<relay-password>hackme</relay_password>|<relay-password>$icecast_pass</relay-password>|g" $icecast_file > /dev/null 2>&1 
sed -i "s|<admin-user>admin</admin-user>|<admin-user>$icecast_user</admin-user>|g" $icecast_file > /dev/null 2>&1 
sed -i "s|<admin-password>hackme</admin-password>|<admin-password>$icecast_pass</admin-password>|g" $icecast_file > /dev/null 2>&1 
sed -i "s|<username>othersource</username>|<username>$icecast_user</username>|g" $icecast_file > /dev/null 2>&1 
sed -i "s|<password>hackmemore</password>|<password>$icecast_pass</password>|g" $icecast_file > /dev/null 2>&1
sed -i "s|<mount-name>/example.complex.ogg</mount-name>|<mount-name>/$resource</mount-name>|g" $icecast_file > /dev/null 2>&1
sed -i "s|<max-listeners>1</max-listeners>|<max-listeners>$listeners</max-listeners>|g" $icecast_file > /dev/null 2>&1

# Reinicio del servicio
service icecast2 restart

########################################################
#                        Pagina Web                    #
########################################################

unzip ~/Erios-Project/page-icecast.zip
rm -rf /var/www/html
sed -i "s|127.0.0.1|$Web|g" ~/Erios-Project/html/index.html
mv ~/Erios-Project/html /var/www/
rm -rf ~/Erios-Project/page-icecast.zip


########################################################
#                         Fin                          #
########################################################

# Mensajes finales
rm -rf ~/Erios-Project > /dev/null 2>&1
echo -e $verde "Instalación y configuración concluida con exito!"
sleep 3s
echo -e $verde "Gracias por confiar en nosotros e instalar el producto"
sleep 2s
echo -e $verde "Si tienes alguna duda, no dudes en preguntarnos"
sleep 3s 
echo -e $verde "Para finalizar con la configuración y que todo funcione correctamente abre los siguientes puertos de tu router:"
sleep 3s
read -n1 -r -p "Presiona [ Enter ] cuando hayas acabado" key
exit
