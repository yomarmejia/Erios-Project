#############################################################
#                     sincronizar.sh                        #
#############################################################

if [ $(id -u) != "0" ]; then
echo -e $rojo[x] Es esencial ser $azul [root] $rojo para ejecutar este setup [x]
echo " "
sleep 2s
exit 0
fi

find / -name gdrive.txt  > .dir-gdrive.txt
sed -i "s|/gdrive.txt||g" .dir-gdrive.txt
dirgdrive="$(cat .dir-gdrive.txt)" > /dev/null 2>&1

mkdir $dirgdrive/gdrive/ > /dev/null 2>&1
cd $dirgdrive/gdrive/
carpeta=$(cat $dirgdrive/gdrive.txt)
gdrive sync content $carpeta
rm -rf $dirgdrive/gdrive/*
