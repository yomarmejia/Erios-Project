#############################################################
#                     sincronizar.sh                        #
#############################################################

if [ $(id -u) != "0" ]; then
echo -e $rojo[x] Es esencial ser $azul [root] $rojo para ejecutar este setup [x]
echo " "
sleep 2s
exit 0
fi

mkdir ~/.Scripts-Erios/gdrive/ > /dev/null 2>&1
cd ~/.Scripts-Erios/gdrive/
carpeta=$(cat ~/.Scripts-Erios/gdrive.txt)
gdrive sync content $carpeta
rm -rf ~/.Scripts-Erios/gdrive/*
