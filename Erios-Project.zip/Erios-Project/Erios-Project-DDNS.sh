#!/bin/bash

########################################################
#          Creación de las variables basicas           #
########################################################

path=`pwd`
arch=`uname -m`
config=$path/config/config.path

# Colores
cian='\e[0;36m'
verde='\e[0;32m'
rojo='\e[1;31m'
amarillo='\e[1;33m'
azul='\e[0;34m'
morado='\e[1;35m'

#######################################################
#                Comprobación de root                 #
#######################################################

if [ $(id -u) != "0" ]; then
echo -e $rojo[x] Es esencial ser $azul [root] $rojo para ejecutar este setup [x]
echo " "
sleep 2s
exit 0
fi

########################################################
#              Aviso de SSH con ejecución              #
########################################################

echo -e $verde "ATENCION!"
sleep 2s
echo -e $verde "Si estas ejecutando este script remotamente con el programa SSH"
sleep 2s
echo -e $verde "Asegurate de que sea con la variable de ejecución"
sleep 2s
echo " "
echo -e $verde "El comando para Linux es el siguiente: $azul ssh -X usuario@servidor"
sleep 2s
echo -e $verde "Y para Windows solo hay que activar el X11 en el programa usado"
read -n1 -r -p "Presiona [ Enter ] cuando quieras continuar" key
clear

########################################################
#            Comprobaciones de sources.list            #
########################################################

file="/etc/apt/sources.list.alarma"
if [ -f $file ]; then
echo -e $verde "Se esta reparando tu lista de repositorios porque se ha detectado que se ha interrumpido una instalación o una actualización"
sleep 3s
rm -f /etc/apt/sources.list
mv /etc/apt/sources.list.alarma /etc/apt/sources.list
echo "Se ha recuperado la lista de repositorios original"
echo "Empezando la instalación de los paquetes"
echo " "
echo "Limpieza de la cache de los anteriores repositorios y acutualizando la lista"
apt clean && apt update -y > /dev/null 2>&1
sleep 2s 
else 
echo -e $verde "Todo en orden"
fi
clear

########################################################
#                       Banner                         #
########################################################

resize -s 21 70 > /dev/null 2>&1

echo -e $cian "╔═══════════════════════════════════════════════════════════════════╗"
echo -e "║                                                                   ║"
echo -e "║                         Erios Project                             ║"
echo -e "║ $rojo         0                                           0           $cian ║"
echo -e "║ $rojo        0       0                             0       0          $cian ║"
echo -e "║ $rojo       0       0     0       00000       0     0       0         $cian ║"
echo -e "║ $rojo      0       0     0      00     00      0     0       0        $cian ║"
echo -e "║ $rojo      0      0     0      0         0      0     0      0        $cian ║"
echo -e "║ $rojo      0      0     0      0    0    0      0     0      0        $cian ║"
echo -e "║ $rojo      0      0     0      0         0      0     0      0        $cian ║"
echo -e "║ $rojo      0       0     0      00     00      0     0       0        $cian ║"
echo -e "║ $rojo       0       0     0       00000       0     0       0         $cian ║"
echo -e "║ $rojo        0       0                             0       0          $cian ║"
echo -e "║ $rojo         0                                           0           $cian ║"
echo "║                                                                   ║"
echo "║                              Creado por:                          ║"
echo "║                                                                   ║"
echo "║                        Yomar Stalin Mejia Capa                    ║"
echo "║                         David Naranjo Risueño                     ║"
echo "╚═══════════════════════════════════════════════════════════════════╝"
sleep 5s
clear

########################################################
#              Comprobación de internet                #
########################################################

echo -e $verde "Comprobando la conexión a internet"
sleep 3s
ping -c 1 google.com > /dev/null 2>&1
if [ "$?" != "0" ]; then
echo -e $rojo "No tienes conexión a internet. Para ejecutar este script es necesaria."
read -n1 -r -p "Se parara la ejecuión. Presiona [ Enter ] para salir" key
exit 0
else
echo -e $verde "Todo correcto!"
sleep 1s
fi
clear


########################################################
#                       Xterm                          #
########################################################

which xterm > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul Xterm $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " --- $azul Xterm $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando XTerm Δ "
apt install xterm -y > /dev/null 2>&1
echo -e $verde "     ✔ Instalado!"
echo " "
find /home -name .Xauthority > dir-xterm.txt
dirxterm="$(cat dir-xterm.txt)" > /dev/null 2>&1
cp $dirxterm ~/ > /dev/null 2>&1
sleep 2s
fi

########################################################
#                         Git                          #
########################################################

which git > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul Git $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " ---$azul Git $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando Git Δ "
xterm -T "Δ Instalando Git Δ" -geometry 100x30 -e "sudo apt install git -y"
echo -e $verde "     ✔ Instalado!"
echo " "
sleep 3s
fi

########################################################
#                       Motion                         #
########################################################

which motion > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul Motion $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " ---$azul Motion $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando Motion Δ "
echo deb http://ftp.es.debian.org/debian jessie-backports main >> /etc/apt/sources.list 
xterm -T "Δ Instalando Motion Δ" -geometry 100x30 -e "sudo apt install motion ffmpeg -y"
echo -e $verde "     ✔ Instalado!"
echo " "
sed -i "s|deb http://ftp.es.debian.org/debian jessie-backports main||g" /etc/apt/sources.list > /dev/null 2>&1
sleep 3s
fi

#############################################################
#                 Postfix -MailUtils                        #
#############################################################

which postfix > /dev/null 2>&1
if [ "$?" -eq "0" ];then
echo -e $verde "Los programas $azul Postfix - MailUtils $verde ya se encuentran instalados!"
echo " "
sleep 3s
else 
echo -e $rojo " ---$azul Postfix - MailUtils $rojo no estan instalados --- "
sleep 1s
echo -e $amarillo "   Δ Instalando Postfix - MailUtils Δ "
xterm -T "Δ Instalando Postfix - MailUtils Δ " -geometry 100x30 -e "sudo DEBIAN_FRONTEND=noninteractive apt install mailutils postfix -y"
echo " "
sleep 3s
fi

########################################################
#                       Gdrive                         #
########################################################

which gdrive > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul GDrive $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " ---$azul GDrive $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando GDrive Δ "

#GDrive viene dentro del paquete de instalación, aprovechamos para hacer una actualización de repositorios.

xterm -T "Δ Instalando GDrive Δ" -geometry 100x30 -e "chmod +x ~/Erios-Project/gdrive && cp ~/Erios-Project/gdrive /usr/bin && mv ~/Erios-Project/gdrive /usr/local/bin"
echo -e $verde "     ✔ Instalado!"
echo " "
sleep 5s
fi

########################################################
#                      DDClient                        #
########################################################

which ddclient > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul DDClient $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " ---$azul DDClient $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando DDClient Δ "
xterm -T "Δ Instalado DDClient Δ" -geometry 100x30 -e "sudo DEBIAN_FRONTEND=noninteractive apt install ddclient -y"
echo -e $verde "    ✔ Instalado!"
echo " "
sleep 5s
fi

########################################################
#                      IceCast 2                       #
########################################################

which icecast2 > /dev/null 2>&1
if [ "$?" -eq "0" ]; then
echo -e $verde "El programa $azul IceCast2 $verde ya se encuentra instalado!"
echo " "
sleep 3s
else
echo -e $rojo " ---$azul IceCast2 $rojo no esta instalado --- "
sleep 1s
echo -e $amarillo "   Δ Instalando IceCast2 Δ "
xterm -T "Δ Instalando IceCast2 Δ" -geometry 100x30 -e "sudo DEBIAN_FRONTEND=noninteractive apt install icecast2 -y"
echo -e $verde "     ✔ Instalado!"
echo " "
sleep 3s
fi
clear

#################################################################
#                   Creación Carpeta Scripts                    #
#################################################################

# Creación del directorio donde se alojará todos los scripts del sistema de videovigilancia.

find /home -name Erios-Project-DDNS.sh > directory.txt
sed -i "s|Erios-Project-DDNS.sh| |g" directory.txt
directory="$(cat directory.txt)" > /dev/null 2>&1
cp -r $directory ~/ > /dev/null 2>&1
mkdir ~/.Scripts-Erios > /dev/null 2>&1
sleep 5s
clear

########################################################
#              Configuración de Motion                 #
########################################################

motion_file=/etc/motion/motion.conf

# Creación del usuario para motion
echo -e $verde "Introduce el usuario con el que vas a entrar al stream y a la configuración: "
read motion_user
echo " "
sleep 2s
echo -e -n $verde "Introduce la contraseña con la que vas a entrar al stream y a la configuración: "
read -s motion_pass
echo " "
sleep 2s
# Creación del directorio donde se alojará el script de encendido y apagado del sistema de vigilancia
mkdir ~/.Scripts-Erios/motion  > /dev/null 2>&1
mkdir ~/.Scripts-Erios/gdrive  > /dev/null 2>&1

# Modificacion del archivo motion.conf
cp /etc/motion/motion.conf /etc/motion/motion.conf.old

sed -i "s|width 320|width 640|g" $motion_file > /dev/null 2>&1
sed -i "s|height 240|height 480|g" $motion_file > /dev/null 2>&1
sed -i "s|threshold 1500|threshold 7500|g" $motion_file > /dev/null 2>&1
sed -i "s|lightswitch 0|lightswitch 95|g" $motion_file > /dev/null 2>&1
sed -i "s|minimum_motion_frames 1|minimum_motion_frames 5|g" $motion_file > /dev/null 2>&1
sed -i "s|evemt_gap 60|event_gap 180|g" $motion_file > /dev/null 2>&1
sed -i "s|quality 75|quality 100|g" $motion_file > /dev/null 2>&1
sed -i "s|ffmpeg_output_movies off|ffmpeg_output_movies on|g" $motion_file > /dev/null 2>&1
sed -i "s|target_dir /var/lib/motion|target_dir ~/.Scripts-Erios/gdrive|g" $motion_file > /dev/null 2>&1
sed -i "s|picture_filename %v-%Y%m%d%H%M%S|picture_filename %Y%m%d/cam1-%v-%H%M%S-%q|g" $motion_file > /dev/null 2>&1
sed -i "s|movie_filename %v-%Y%m%d%H%M%S|movie_filename %Y%m%d/cam1-%v-%H%M%S-%q|g" $motion_file > /dev/null 2>&1
sed -i "s|stream_port 8080|stream_port 8081|g" $motion_file > /dev/null 2>&1
sed -i "s|stream_localhost on|stream_localhost off|g" $motion_file > /dev/null 2>&1
sed -i "s|stream_auth_method 0|stream_auth_method 2|g" $motion_file > /dev/null 2>&1
sed -i "s|; stream_authentication username:password| stream_authentication $motion_user:$motion_pass|g" $motion_file > /dev/null 2>&1
sed -i "s|webcontrol_port 0|webcontrol_port 8082|g" $motion_file > /dev/null 2>&1
sed -i "s|webcontrol_localhost on|webcontrol_localhost off|g" $motion_file > /dev/null 2>&1
sed -i "s|; on_event_start value|on_event_start ~/.Scripts-Erios/motion/haymovimiento.sh|g" $motion_file > /dev/null 2>&1
sed -i "s|; on_event_end value|on_event_end ~/.Scripts-Erios/motion/sincronizar.sh|g" $motion_file > /dev/null 2>&1

# Reinicio del servicio
service motion restart

# Copia y Permisos a los scripts
chmod +x ~/Erios-Project/*.sh
mv ~/Erios-Project/haymovimiento.sh ~/.Scripts-Erios/motion
mv ~/Erios-Project/sincronizar.sh ~/.Scripts-Erios/motion

# Copia de los scripts al binario de Linux

cp ~/Erios-Project/start.sh /usr/bin > /dev/null 2>&1
mv ~/Erios-Project/start.sh /usr/local/bin > /dev/null 2>&1
cp ~/Erios-Project/stop.sh /usr/bin > /dev/null 2>&1
mv ~/Erios-Project/stop.sh /usr/local/bin > /dev/null 2>&1
clear

# Info
echo -e $verde "El comando $azul \"start.sh\" $verde comienza la detección de movimiento y tendras 30 segundos para salir de la zona"
echo -e $verde "El comando $azul \"stop.sh\" $verde detiene la detección de movimiento"
sleep 5s

##########################################################
#      Configuración de Postfix - MailUtils             #
##########################################################

postfix_file=/etc/postfix/main.cf

# Identificación de la cuenta de correo y contraseña
echo -e -n $verde  "Introduce tu cuenta de correo (IMPORTANTE! Tiene que ser de GMail): "
read postfix_cuenta
echo $postfix_cuenta > ~/.Scripts-Erios/mail.txt
echo " "
echo -n "Ahora introduce tu contraseña de GMail (Nadie la va a poder ver): "
read -s postfix_pass
echo " "

# Creacion del archivo sasl
echo "[smtp.gmail.com]:587 $postfix_cuenta:$postfix_pass" > /etc/postfix/sasl_gmail
postmap /etc/postfix/sasl_gmail
chown root:root /etc/postfix/sasl_gmail /etc/postfix/sasl_gmail.db
chmod 0600 /etc/postfix/sasl_gmail /etc/postfix/sasl_gmail.db

# Modificacion del archivo /etc/postfix/main.cf
sed -i "s|relayhost =|relayhost = [smtp.gmail.com]:587|g" $postfix_file > /dev/null 2>&1
sed -i "s|inet_protocol = all|inet_protocol = ipv4|g" $postfix_file > /dev/null 2>&1
echo " " >> $postfix_file
echo "smtp_sasl_auth_enable = yes" >> $postfix_file
echo "smtp_sasl_password_maps = hash:/etc/postfix/sasl_gmail" >> $postfix_file
echo "smtp_sasl_security_options =" >> $postfix_file
echo "smtp_tls_security_level = encrypt" >> $postfix_file

# Reinicio del servicio
service postfix restart

# Comprobación del servicio
echo -e $verde "Este es un mensaje para comprobar el funcionamiento del servicio." | mail -s "Mensaje de prueba" $postfix_cuenta
sleep 2s
echo -e $verde "Se ha enviado un mensaje de prueba. Comprueba la bandeja de entrada o tu SPAM de tu cuenta GMAIL."
sleep 3s
echo -e "Lo has recibido? [ Si o No]: "
read respuesta

if [ $respuesta = "No" ]; then
echo -e $rojo "Ha habido un error en la configuración. Reportalo a los creadores y se pondran en contacto lo mas pronto posible"
echo -e $rojo "Codigo de Error = P001"
echo -e $rojo "Se parará la ejecución. Presiona [ Enter ] para salir."
read abort
exit
fi
if [ $respuesta = "Si" ]; then
echo -e $verde "De acuerdo, todo correcto!"
fi
clear

########################################################
#              Configuración de GDrive                 #
########################################################

# Pregunta del recurso
echo -e $verde "Como quieres nombrar a tu recurso en Google Drive? "
read gdrive_resource

# Configuración libre de GDrive
echo " "
echo -e $verde "A continuación sigue las instrucciones sincronizar tu cuenta $azul Google Drive."
sleep 5s
gdrive about
sleep 2s
# Creacion de la carpeta de sincronización de las imagenes:
gdrive mkdir $gdrive_resource > ~/.Scripts-Erios/gdrive.txt
sed -i "s|Directory||g" ~/.Scripts-Erios/gdrive.txt
sed -i "s|created||g" ~/.Scripts-Erios/gdrive.txt
clear

########################################################
#              Configuración de DDClient               #
########################################################

ddclient_file=/etc/ddclient.conf

# Instrucciones de la creacion del servidor
echo -e $verde "Crea un subdominio en una página web dedicada a ello."
sleep 3s
echo -e $verde "Recomendamos http://www.changeip.com"
sleep 3s
echo -e $verde "Una vez hecho, responde las siguientes pregunts:"
sleep 2s
echo -e $verde "Ante cualquier duda, ponte en contacto con los creadores"
sleep 3s
read -n1 -r -p "Presiona [ Enter ] cuando lo hayas creado" key
echo " "

# Creación de las variables para configurar DDClient
echo -e -n $verde "Nombre del servidor DDNS remoto: "
read ddclient_server 
echo $ddclient_server > ~/.Scripts-Erios/web.txt
echo -e -n $verde "Correo de acceso al servicio DDNS: "
read ddclient_mail
echo -e -n $verde "Contraseña de acceso al servicio DDNS: "
read -s ddclient_pass
echo -e -n $verde "Que interface utilizaras para la conexión? (ej. eth0, wlan0)"
read ddclient_interface
sleep 5s

# Configuración automatica de DDClient
rm -rf /etc/ddclient.conf
echo "# Archivo de Configuración para ddclient Generado por Erios-Project" >> $ddclient_file
echo "#" >> $ddclient_file
echo " " >> $ddclient_file
echo "pid=/var/run/ddclient.pid" >> $ddclient_file
echo "protocol=dyndns2" >> $ddclient_file
echo "use=web, if=$ddclient_interface" >> $ddclient_file
echo "server=$ddclient_server" >> $ddclient_file
echo "login=$ddclient_mail" >> $ddclient_file
echo "password='$ddclient_pass'"
echo $ddclient_server >> $ddclient_file

# Reinicio del servicio
service ddclient restart > /dev/null 2>&1
clear

########################################################
#              Configuración de IceCast2               #
########################################################

icecast_file=/etc/icecast2/icecast.xml

# Creación de usuario y contraseña para la página web
echo -e -n $verde "Introduce el usuario de acceso a Icecast: "
read icecast_user
echo $icecast_user > ~/.Scripts-Erios/userIC.txt
echo " "
echo -e -n $verde "Introduce la contraseña de acceso a Icecast: "
read -s icecast_pass
echo icecast_pass > ~/.Scripts-Erios/passIC.txt
echo " "
echo -e -n $verde "Instroduce el nombre del recurso para la imagen con la extension .ogg (Por ejemplo: video.ogg): "
read resource
echo $resource > ~/.Scripts-Erios/resIC.txt
echo " "
echo -e -n $verde "Cual es el máximo de usuarios que van a acceder a la vez? [1 a 9]: "
read listeners
echo " "

# Modificiación del archivo /etc/icecast2/icecast.xml
sed -i "s|<source-password>hackme</source-password>|<source-password>$icecast_pass</source-password>|g" $icecast_file > /dev/null 2>&1
sed -i "s|<relay-password>hackme</relay_password>|<relay-password>$icecast_pass</relay-password>|g" $icecast_file > /dev/null 2>&1 
sed -i "s|<admin-user>admin</admin-user>|<admin-user>$icecast_user</admin-user>|g" $icecast_file > /dev/null 2>&1 
sed -i "s|<admin-password>hackme</admin-password>|<admin-password>$icecast_pass</admin-password>|g" $icecast_file > /dev/null 2>&1 
sed -i "147d" $icecast_file > /dev/null 2>&1 
sed -i "173d" $icecast_file > /dev/null 2>&1
sed -i '<authentication type="htpasswd">|<\!-- <authentication type="htpasswd">|g' $icecast_file > /dev/null 2>&1
sed -i "s|165|</authentication> -->|g" $icecast_file > /dev/null 2>&1
sed -i "s|<username>othersource</username>|<username>$icecast_user</username>|g" $icecast_file > /dev/null 2>&1 
sed -i "s|<password>hackmemore</password>|<password>$icecast_pass</password>|g" $icecast_file > /dev/null 2>&1
sed -i "s|<mount-name>/example.complex.ogg</mount-name>|<mount-name>/$resource</mount-name>|g" $icecast_file > /dev/null 2>&1
sed -i "s|<max-listeners>1</max-listeners>|<max-listeners>$listeners</max-listeners>|g" $icecast_file > /dev/null 2>&1

# Reinicio del servicio
service icecast2 restart

########################################################
#                         Fin                          #
########################################################

# Binarios del ffmpeg
chmod +x ~/Erios-Project/ffmpegVA.sh
cp ~/Erios-Project/ffmpegVA.sh /usr/bin > /dev/null 2>&1
mv ~/Erios-Project/ffmpegVA.sh /usr/local/bin > /dev/null 2>&1

# Edicion del crontab
echo "@reboot ffmpegVA.sh"

# Mensajes finales
rm -rf ~/Erios-Project > /dev/null 2>&1
echo -e $verde "Instalación y configuración concluida con exito!"
sleep 3s
echo -e $verde "Gracias por confiar en nosotros e instalar el producto"
sleep 2s
echo -e $verde "Si tienes alguna duda, no dudes en preguntarnos"
sleep 3s 
echo -e $verde "Para finalizar con la configuración y que todo funcione correctamente abre los siguientes puertos de tu router:"
sleep 3s
echo -e $verde " 8000 - 8081 -8082 "
sleep 1s
read -n1 -r -p "Presiona [ Enter ] cuando hayas acabado" key
exit
