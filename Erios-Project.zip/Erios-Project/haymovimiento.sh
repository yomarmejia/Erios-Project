#############################################################
#                  haymovimiento.sh                         #
#############################################################

find / -name web.txt  > .dir-web.txt
sed -i "s|/web.txt||g" .dir-web.txt
dirweb="$(cat .dir-web.txt)" > /dev/null 2>&1

web=$(cat $dirweb/web.txt)
resource=$(cat $dirweb/resIC.txt)

echo "Se ha detectado movimiento en una de las camaras del sistema \
\
Proximamente tendras el resultado de las imagenes en tu drive sincronizado:\
Puedes revisar la señal de la camara en directo en el siguiente enlace: \
$web:8000/$resource" | mail -s "Alerta! Se ha detectado movimiento!" -A $dirweb/gdrive/*snapshot.png



